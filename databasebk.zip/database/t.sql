
SELECT 
    `sales`.`sale_id` AS `sale_id`, `sales`.`code` as `code`, `sales`.`confirm` as `confirm`, 
    `sales`.`sale_uuid` as `sale_uuid`, `customer`.`account_number` as `account_number`, 
    DATE(sales.sale_time) AS sale_date, `sales`.`sale_time` AS `sale_time`, `sales`.`comment` AS `comment`, 
    `sales`.`invoice_number` AS `invoice_number`, `sales`.`employee_id` AS `employee_id`, `sales`.`customer_id` AS `customer_id`, 
    `sales`.`ctv_id` AS `sale_man_id`, CONCAT(customer_p.first_name, " ", customer_p.last_name) AS customer_name, 
    `customer_p`.`first_name` AS `first_name`, `customer_p`.`last_name` AS `last_name`, 
    `customer_p`.`email` AS `email`, `customer_p`.`comments` AS `comments`, `customer`.`customer_uuid` AS `c_uuid`, 
    `customer_p`.`phone_number` AS `phone_number`, 
    IFNULL(ROUND(SUM(sales_items.item_unit_price * sales_items.quantity_purchased * (1 - sales_items.discount_percent / 100)), 0), ROUND(SUM(sales_items.item_unit_price * sales_items.quantity_purchased * (1 - sales_items.discount_percent / 100) * (100 / (100 + sales_items_taxes.percent))), 0)) AS amount_due, 
    `payments`.`sale_payment_amount` AS `amount_tendered`, (payments.sale_payment_amount - IFNULL(ROUND(SUM(sales_items.item_unit_price * sales_items.quantity_purchased * (1 - sales_items.discount_percent / 100)), 0), ROUND(SUM(sales_items.item_unit_price * sales_items.quantity_purchased * (1 - sales_items.discount_percent / 100) * (100 / (100 + sales_items_taxes.percent))), 0))) AS change_due, 
    `payments`.`payment_type` AS `payment_type` 
FROM `ospos_sales_items` AS `sales_items` 
    INNER JOIN `ospos_sales` AS `sales` ON `sales_items`.`sale_id` = `sales`.`sale_id` 
    LEFT JOIN `ospos_people` AS `customer_p` ON `sales`.`customer_id` = `customer_p`.`person_id` 
    LEFT JOIN `ospos_customers` AS `customer` ON `sales`.`customer_id` = `customer`.`person_id` 
    LEFT OUTER JOIN `ospos_sales_payments_temp` AS `payments` ON `sales`.`sale_id` = `payments`.`sale_id` 
    LEFT OUTER JOIN `ospos_sales_items_taxes_temp` AS `sales_items_taxes` ON `sales_items`.`sale_id` = `sales_items_taxes`.`sale_id` AND `sales_items`.`item_id` = `sales_items_taxes`.`item_id` 
WHERE `sales`.`sale_uuid` 
IS NULL GROUP BY `sales`.`sale_id` 
ORDER BY `sales`.`sale_time` ASC


CREATE TEMPORARY TABLE IF NOT EXISTS  ospos_sales_payments_temp 
(
    SELECT payments.sale_id AS sale_id, 
    IFNULL(SUM(payments.payment_amount), 0) AS sale_payment_amount,
    GROUP_CONCAT(CONCAT(payments.payment_type, " ", payments.payment_amount) SEPARATOR ", ") AS payment_type
    FROM  ospos_sales_payments  AS payments
    INNER JOIN  ospos_sales AS sales
    ON sales.sale_id = payments.sale_id
    GROUP BY sale_id
)

SELECT payments.sale_id AS sale_id, payments.*
    
    FROM  ospos_sales_payments  AS payments
    INNER JOIN  ospos_sales AS sales
    ON sales.sale_id = payments.sale_id
    GROUP BY sale_id