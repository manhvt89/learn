-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 19, 2022 at 02:58 PM
-- Server version: 10.3.37-MariaDB-0ubuntu0.20.04.1
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `namh_sys`
--

-- --------------------------------------------------------

--
-- Table structure for table `ospos_roles`
--

CREATE TABLE `ospos_roles` (
  `id` int(10) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `display_name` varchar(250) DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `role_uuid` varchar(250) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT 0,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `deleted_at` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_roles`
--

INSERT INTO `ospos_roles` (`id`, `name`, `display_name`, `code`, `role_uuid`, `created_at`, `updated_at`, `deleted_at`, `status`, `description`) VALUES
(1, 'admin', 'admin', 'ADM', '7b498149-5877-11ed-a953-040300000000', 0, 0, 0, 0, '1'),
(2, 'Bán hàng', 'Bán hàng', 'SALE', '7b4984a5-5877-11ed-a953-040300000000', 0, 0, 0, 0, '1'),
(3, 'Thu ngân', 'Thu ngân', 'thungan', '7b4985c8-5877-11ed-a953-040300000000', 0, 0, 0, 0, '1'),
(4, 'Thủ kho', 'Thủ kho', 'thukho', '7b498693-5877-11ed-a953-040300000000', 0, 0, 0, 0, '1'),
(5, 'Quản lý', 'Quản lý', 'MGR', '7b49875d-5877-11ed-a953-040300000000', 0, 0, 0, 0, '1'),
(6, 'Nhà đầu tư', 'Nhà đầu tư', 'NDT', '7b498829-5877-11ed-a953-040300000000', 0, 0, 0, 0, '1'),
(7, 'Đo mắt', 'Đo mắt', 'DM', '0', 0, 0, 0, 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ospos_roles`
--
ALTER TABLE `ospos_roles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ospos_roles`
--
ALTER TABLE `ospos_roles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
