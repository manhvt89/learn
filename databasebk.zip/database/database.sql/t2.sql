CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT '0.000',
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT '1.000',
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_id` int(10) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `custom1` varchar(25) NOT NULL,
  `custom2` varchar(25) NOT NULL,
  `custom3` varchar(25) NOT NULL,
  `custom4` varchar(25) NOT NULL,
  `custom5` varchar(25) NOT NULL,
  `custom6` varchar(25) NOT NULL,
  `custom7` varchar(25) NOT NULL,
  `custom8` varchar(25) NOT NULL,
  `custom9` varchar(25) NOT NULL,
  `custom10` varchar(25) NOT NULL,
  `standard_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `item_number_new` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: mới tạo; 1 đã đồng bộ; 3 edited; ',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_number` (`item_number`),
  KEY `supplier_id` (`supplier_id`),
  KEY `unit_cost` (`unit_price`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4731 DEFAULT CHARSET=utf8;

SELECT `total`.`total_id` as `total_id`, `total`.`amount` as `amount`, `total`.`type` as `type`, CONCAT(people.last_name, " ", people.first_name) as person, CONCAT(people1.last_name, " ", people1.first_name) as employee, `total`.`note` as `note`, `total`.`created_time` as `created_time` FROM `ospos_total` AS `total` 
LEFT JOIN `ospos_people` AS `people` ON `total`.`personal_id` = `people`.`person_id` 
LEFT JOIN `ospos_people` AS `people1` ON `total`.`creator_personal_id` = `people1`.`person_id` 
WHERE DATE(FROM_UNIXTIME(total.created_time)) BETWEEN '2022-11-11' AND '2022-11-17' ORDER BY `created_time` DESC LIMIT 25

SELECT `total`.`total_id` as `total_id`, `total`.`amount` as `amount`, `total`.`type` as `type`, CONCAT(people.last_name, " ", people.first_name) as person, CONCAT(people1.last_name, " ", people1.first_name) as employee, `total`.`note` as `note`, (FROM_UNIXTIME(total.created_time)) as `created_time` FROM `ospos_total` AS `total` 
LEFT JOIN `ospos_people` AS `people` ON `total`.`personal_id` = `people`.`person_id` 
LEFT JOIN `ospos_people` AS `people1` ON `total`.`creator_personal_id` = `people1`.`person_id` 
WHERE DATE(FROM_UNIXTIME(total.created_time)) BETWEEN '2022-11-16' AND '2022-11-17' ORDER BY `created_time` DESC LIMIT 25

SELECT `total`.`total_id` as `total_id`, `total`.`amount` as `amount`, `total`.`type` as `type` (FROM_UNIXTIME(total.created_time)) as `created_time` FROM `ospos_total` AS `total` WHERE DATE(FROM_UNIXTIME(total.created_time)) BETWEEN '2022-11-16' AND '2022-11-17' ORDER BY `created_time` DESC LIMIT 25