-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 19, 2022 at 02:58 PM
-- Server version: 10.3.37-MariaDB-0ubuntu0.20.04.1
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `namh_sys`
--

-- --------------------------------------------------------

--
-- Table structure for table `ospos_modules`
--
DROP TABLE IF EXISTS `ospos_modules`;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_key` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `code` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `created_at` int(11) NOT NULL DEFAULT 0,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `deleted_at` int(11) NOT NULL DEFAULT 0,
  `module_uuid` varchar(250) NOT NULL DEFAULT uuid()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_modules`
--

INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_key`, `id`, `code`, `name`, `created_at`, `updated_at`, `deleted_at`, `module_uuid`) VALUES
('module_account', 'module_account_desc', 120, 'account', 1, NULL, 'Kế toán', 0, 0, 0, 'aa3922b7-5819-11ed-b65f-040300000000'),
('module_config', 'module_config_desc', 130, 'config', 2, NULL, 'Thiết lập', 0, 0, 0, 'aa392523-5819-11ed-b65f-040300000000'),
('module_customers', 'module_customers_desc', 10, 'customers', 3, NULL, 'Khách hàng', 0, 0, 0, 'aa3926ef-5819-11ed-b65f-040300000000'),
('module_customer_info', 'module_customer_info', 121, 'customer_info', 4, NULL, 'Bảo hành', 0, 0, 0, 'aa3927cc-5819-11ed-b65f-040300000000'),
('module_employees', 'module_employees_desc', 80, 'employees', 5, NULL, 'Nhân viên', 0, 0, 0, 'aa3928f4-5819-11ed-b65f-040300000000'),
('module_giftcards', 'module_giftcards_desc', 90, 'giftcards', 6, NULL, 'Quà tặng', 0, 0, 0, 'aa392a99-5819-11ed-b65f-040300000000'),
('module_items', 'module_items_desc', 20, 'items', 7, NULL, 'Sản phẩm', 0, 0, 0, 'aa392b4c-5819-11ed-b65f-040300000000'),
('module_item_kits', 'module_item_kits_desc', 30, 'item_kits', 8, NULL, 'Nhóm sản phẩm', 0, 0, 0, 'aa392bf1-5819-11ed-b65f-040300000000'),
('module_messages', 'module_messages_desc', 100, 'messages', 9, NULL, 'Tin nhắn', 0, 0, 0, 'aa392ca6-5819-11ed-b65f-040300000000'),
('module_order', 'module_order_desc', 150, 'order', 10, NULL, NULL, 0, 0, 0, 'aa392d4a-5819-11ed-b65f-040300000000'),
('module_receivings', 'module_receivings_desc', 60, 'receivings', 11, NULL, 'Nhập hàng', 0, 0, 0, 'aa392df2-5819-11ed-b65f-040300000000'),
('module_reminders', 'module_reminders_desc', 140, 'reminders', 12, NULL, NULL, 0, 0, 0, 'aa392ea1-5819-11ed-b65f-040300000000'),
('module_reports', 'module_reports_desc', 50, 'reports', 13, NULL, 'Báo cáo', 0, 0, 0, 'aa392f58-5819-11ed-b65f-040300000000'),
('module_sales', 'module_sales_desc', 70, 'sales', 14, NULL, 'Bán hàng', 0, 0, 0, 'aa393000-5819-11ed-b65f-040300000000'),
('module_suppliers', 'module_suppliers_desc', 40, 'suppliers', 15, NULL, 'Nhà cung cấp', 0, 0, 0, 'aa3930d4-5819-11ed-b65f-040300000000'),
('module_test', 'module_test_desc', 110, 'test', 16, NULL, 'Đo mắt', 0, 0, 0, 'aa393173-5819-11ed-b65f-040300000000'),
('roles', 'roles', 10, 'roles', 17, 'roles', 'Phân quyền', 1667225850, 0, 0, 'c14fb1fe-5926-11ed-b3d8-040300000000'),
('barcodes', 'barcodes', 10, 'barcodes', 18, 'barcodes', 'Quản lý barcode', 1669912730, 0, 0, 'a29e2092-7196-11ed-8174-005056847d3e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ospos_modules`
--
ALTER TABLE `ospos_modules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  ADD UNIQUE KEY `name_lang_key` (`name_lang_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ospos_modules`
--
ALTER TABLE `ospos_modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
