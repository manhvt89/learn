-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 19, 2022 at 02:58 PM
-- Server version: 10.3.37-MariaDB-0ubuntu0.20.04.1
-- PHP Version: 7.4.33
-- Update to v_namhai branch

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

ALTER TABLE ospos_app_config CHANGE `value` `value` VARCHAR (65000);

ALTER TABLE `ospos_sales` ADD COLUMN IF NOT EXISTS `parent_id` int(10) NOT NULL DEFAULT '0' AFTER `ctv_id`;
ALTER TABLE `ospos_sales` ADD COLUMN IF NOT EXISTS `current` int(4) NOT NULL DEFAULT '1' COMMENT '0 là cha, đã bị thay thế; 1: hiện tại đang dùng' AFTER `ctv_id`;

ALTER TABLE `ospos_employees` ADD COLUMN IF NOT EXISTS `log` varchar(10) NOT NULL DEFAULT '0' AFTER `type`;

DROP TABLE IF EXISTS `ospos_purchases_items`;
-- /*!40101 SET @saved_cs_client     = @@character_set_client */
-- /*!40101 SET character_set_client = utf8 */
CREATE TABLE `ospos_purchases_items`(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT 0,
  `purchase_id` int(11) DEFAULT 0,
  `item_number` varchar(250) DEFAULT NULL,
  `item_name` varchar(250) DEFAULT NULL,
  `item_quantity` varchar(250) DEFAULT NULL,
  `item_price` varchar(250) DEFAULT NULL,
  `item_u_price` varchar(250) DEFAULT NULL,
  `item_category` varchar(250) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `type` tinyint(1) DEFAULT '0' COMMENT '0 cũ; 2: sp mới; 3: sp mới đã tồn tại barcode Đã tồn tại',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- /*!40101 SET character_set_client = @saved_cs_client */

DROP TABLE IF EXISTS `ospos_purchases`;
CREATE TABLE `ospos_purchases` (
  `purchase_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supplier_id` int(10) DEFAULT 0,
  `parent_id` int(10) DEFAULT 0,
  `curent` int(4) DEFAULT 1,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `edited_employee_id` int(10) NOT NULL DEFAULT 0,
  `approved_employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '0' COMMENT '{1: dat coc;0: thanh toan đủ - hoàn thành}',
  `code` varchar(14) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0' COMMENT '0 draf; 1 Yêu cầu sửa lại; 2 đang chờ duyệt ;3: đã phê duyệt;4 nhập hàng;',
  `name` varchar(250) DEFAULT NULL,
  `total_quantity` varchar(250) DEFAULT '0',
  `total_amount` varchar(250) DEFAULT '0',
  `purchase_uuid` varchar(250) NOT NULL DEFAULT uuid(),
  `edited_time` timestamp DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


COMMIT;

-- /*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */
-- /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */
-- /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */
